import tkinter as tk
import threading
import requests
import time

class WebhookSender:
    def __init__(self, root):
        self.root = root
        self.root.title("Webhook Sender")
        self.root.configure(bg="black")
        
        self.webhook_url = tk.StringVar()
        self.message_content = tk.StringVar()
        
        tk.Label(root, text="Webhook URL:", font=("Arial", 14), fg="black", bg="red").pack(pady=10)
        tk.Entry(root, textvariable=self.webhook_url, width=50, font=("Arial", 14), fg="black", bg="white", highlightbackground="red", highlightcolor="red", highlightthickness=2).pack(pady=10)
        
        self.start_button = tk.Button(root, text="START", command=self.start_sending, font=("Arial", 14), width=20, height=2, fg="black", bg="red")
        self.start_button.pack(pady=10)
        
        self.stop_button = tk.Button(root, text="STOP", command=self.stop_sending, font=("Arial", 14), width=20, height=2, fg="black", bg="red")
        self.stop_button.pack(pady=10)
        
        tk.Label(root, text="Message Content:", font=("Arial", 14), fg="black", bg="red").pack(pady=10)
        tk.Entry(root, textvariable=self.message_content, width=50, font=("Arial", 14), fg="black", bg="white", highlightbackground="red", highlightcolor="red", highlightthickness=2).pack(pady=10)
        
        tk.Label(root, text="エビフライ", font=("Arial", 14), fg="black", bg="red").pack(pady=20)
        
        self.sending = False

    def start_sending(self):
        self.sending = True
        self.thread = threading.Thread(target=self.send_webhook)
        self.thread.start()

    def stop_sending(self):
        self.sending = False
        if self.thread.is_alive():
            self.thread.join()

    def send_webhook(self):
        while self.sending:
            requests.post(self.webhook_url.get(), json={"content": self.message_content.get()})
            time.sleep(1)  # 1秒ごとに送信

if __name__ == "__main__":
    root = tk.Tk()
    app = WebhookSender(root)
    root.mainloop()
